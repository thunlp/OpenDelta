import os
default_cache_path = "{}/.cache/delta_center/".format(os.path.expanduser('~'))
WEIGHTS_NAME = 'pytorch_model.bin'